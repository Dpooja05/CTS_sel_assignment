package dataprovider;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import ddfw.basic_testlogin;

public class dataprovider_login_xl extends excel_to_arr
{
basic_testlogin test;
	
	@BeforeClass
	public void get_data()
	{
		get_test_data();
	}
		
		  @Test(dataProvider="login_data")
		  public void logintest(String eid, String pwd, String exp_eid) 
		  {
			  test = new basic_testlogin();
			  String a_eid = test.login(eid, pwd);
			  SoftAssert sa = new SoftAssert();
			  sa.assertEquals(a_eid, exp_eid);
			  sa.assertAll();
			  
		  }
		  
		  @DataProvider(name="login_data")
		  public String[][] provide_data()
		  {
			return testdata;
		  }
}
