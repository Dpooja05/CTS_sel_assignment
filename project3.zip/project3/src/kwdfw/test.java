package kwdfw;

public class test {
	public static void main(String[] args) 
	{
		excel_operations2 excel = new excel_operations2();
		excel.write_excel(0, 1, "STEP_NO");
		excel.write_excel2(3, 4, "java");
		excel.write_excel3(3, 3, "login");
	}
}
