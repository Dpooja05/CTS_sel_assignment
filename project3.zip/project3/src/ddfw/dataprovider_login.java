package ddfw;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider_login {

	basic_testlogin test;
	
	  @Test(dataProvider="login_data")
	  public void logintest(String eid, String pwd, String exp_eid) {
		  test = new basic_testlogin();
		  String a_eid = test.login(eid, pwd);
		  SoftAssert sa = new SoftAssert();
		  sa.assertEquals(a_eid, exp_eid);
		  sa.assertAll();
		  
	  }
	  
	  @DataProvider(name="login_data")
	  public String[][] provide_data()
	  {
		  String[][] data = {
				  {"trainingservices06@gmail.com", "password", "trainingservices06@gmail.com"},
				  {"trainingservices06@gmail.com", "password", "trainingservices05@gmail.com"}

		  };
		return data;
	  }
}
